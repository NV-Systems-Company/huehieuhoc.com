<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NV Systems <hoangnt@nguyenvan.vn>
 * @Copyright (C) 2021 NV Systems. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Sun, 03 Jan 2021 05:38:40 GMT
 */

if (!defined('NV_ADMIN'))
    die('Stop!!!');

$submenu['config'] = $lang_module['config'];
$submenu['donors'] = $lang_module['donors'];
$submenu['org'] = $lang_module['org'];
$submenu['campaigns'] = $lang_module['campaigns'];
$submenu['donations'] = $lang_module['donations'];
$submenu['payment'] = $lang_module['payment'];
$submenu['list-donation'] = $lang_module['list-donation'];
