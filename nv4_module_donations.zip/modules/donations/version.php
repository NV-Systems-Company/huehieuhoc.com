<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NV Systems <hoangnt@nguyenvan.vn>
 * @Copyright (C) 2021 NV Systems. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Sun, 03 Jan 2021 05:38:40 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$module_version = array(
    'name' => 'Donations',
    'modfuncs' => 'main,detail,search,donors,org,donations,payment',
    'change_alias' => 'main,detail,search,donors,org,donations,payment',
    'submenu' => 'main,detail,search,donors,org,donations,payment',
    'is_sysmod' => 0,
    'virtual' => 1,
    'version' => '4.3.03',
    'date' => 'Sun, 3 Jan 2021 05:38:40 GMT',
    'author' => 'NV Systems (hoangnt@nguyenvan.vn)',
    'uploads_dir' => array($module_name),
    'note' => 'Module Donations'
);
