<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NV Systems <hoangnt@nguyenvan.vn>
 * @Copyright (C) 2021 NV Systems. All rights reserved
 * @License: Not free read more http://nukeviet.vn/vi/store/modules/nvtools/
 * @Createdate Sun, 03 Jan 2021 05:38:40 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_campaigns";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_donations";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_donors";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_org";
$sql_drop_module[] = "DROP TABLE IF EXISTS " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_payment";

$sql_create_module = $sql_drop_module;
$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_campaigns (
 id int(11) unsigned NOT NULL AUTO_INCREMENT,
  CampaignName varchar(255) DEFAULT NULL,
  Description varchar(255) DEFAULT NULL,
  StartDate date DEFAULT NULL,
  OrgId int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (id),
  KEY fk_campaigns (OrgId),
  CONSTRAINT fk_campaigns FOREIGN KEY (OrgId) REFERENCES org (id) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_donations (
 id int(11) unsigned NOT NULL AUTO_INCREMENT,
  CampaignId int(11) unsigned NOT NULL,
  Amount decimal(64,0) DEFAULT NULL,
  Date date DEFAULT NULL,
  Notes varchar(255) DEFAULT NULL,
  DonorId int(11) unsigned NOT NULL,
  PRIMARY KEY (id),
  KEY idx_donations (CampaignId),
  KEY idx_donations_0 (DonorId),
  CONSTRAINT fk_donations FOREIGN KEY (CampaignId) REFERENCES campaigns (id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT fk_donations_0 FOREIGN KEY (DonorId) REFERENCES donors (id) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_donors (
 id int(11) unsigned NOT NULL AUTO_INCREMENT,
  Name varchar(255) DEFAULT NULL,
  FirstName varchar(255) DEFAULT NULL,
  MiddleName char(1) DEFAULT NULL,
  LastName varchar(255) DEFAULT NULL,
  Email varchar(255) DEFAULT NULL,
  Phone varchar(255) DEFAULT NULL,
  Address varchar(255) DEFAULT NULL,
  Address_Street_1 varchar(255) DEFAULT NULL,
  Address_Street_2 varchar(255) DEFAULT NULL,
  City varchar(100) DEFAULT NULL,
  State varchar(255) DEFAULT NULL,
  Zip varchar(255) DEFAULT NULL,
  Country varchar(255) DEFAULT NULL,
  Occupation varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_org (
 id int(11) unsigned NOT NULL AUTO_INCREMENT,
  Name varchar(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM;";

$sql_create_module[] = "CREATE TABLE " . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_payment (
 id int(11) unsigned NOT NULL AUTO_INCREMENT,
  CampaignId int(11) unsigned NOT NULL,
  Amount decimal(64,0) DEFAULT NULL,
  Date date DEFAULT NULL,
  Notes varchar(255) DEFAULT NULL,
  DonorId int(11) unsigned NOT NULL,
  PRIMARY KEY (id),
  KEY idx_donations (CampaignId),
  KEY idx_donations_0 (DonorId),
  CONSTRAINT fk_donations FOREIGN KEY (CampaignId) REFERENCES campaigns (id) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT fk_donations_0 FOREIGN KEY (DonorId) REFERENCES donors (id) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=MyISAM;";

// Comments
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'auto_postcomm', '1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'allowed_comm', '-1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'view_comm', '6')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'setcomm', '4')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'activecomm', '1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'emailcomm', '0')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'adminscomm', '')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'sortcomm', '0')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'captcha', '1')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'perpagecomm', '5')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'timeoutcomm', '360')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'allowattachcomm', '0')";
$sql_create_module[] = "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES ('" . $lang . "', '" . $module_name . "', 'alloweditorcomm', '0')";
